"""Generate a test image containing Devanagari Sanskrit text."""
from PIL import Image, ImageDraw, ImageFont
import os

FONT_PATH = "/usr/share/fonts/truetype/freefont/FreeSerif.ttf"

# Sanskrit shlokas - well known
LINES = [
    "सत्यमेव जयते।",
    "वसुधैव कुटुम्बकम्।",
    "अहिंसा परमो धर्मः।",
    "विद्या ददाति विनयम्।",
]

W, H = 900, 500
# Slightly off-white paper-like background with noise-ish texture
img = Image.new("RGB", (W, H), (245, 240, 225))
draw = ImageDraw.Draw(img)

# Draw some subtle horizontal rule lines to simulate manuscript ruling
for y in range(60, H, 90):
    draw.line([(40, y + 60), (W - 40, y + 60)], fill=(210, 200, 175), width=1)

# Draw a border to simulate folio edges
draw.rectangle([(15, 15), (W - 15, H - 15)], outline=(120, 100, 70), width=2)

font_large = ImageFont.truetype(FONT_PATH, 48)
font_small = ImageFont.truetype(FONT_PATH, 22)

# Title
draw.text((60, 25), "Sanskrit Verses", font=font_small, fill=(90, 60, 30))

y = 90
for line in LINES:
    draw.text((60, y), line, font=font_large, fill=(30, 25, 20))
    y += 90

# Save as JPEG (real feature-rich content: text + lines + borders)
out_path = "/app/test_fixtures/sanskrit_test.jpg"
img.save(out_path, "JPEG", quality=92)
print(f"Saved: {out_path} ({os.path.getsize(out_path)} bytes)")

# Also PNG
img.save("/app/test_fixtures/sanskrit_test.png", "PNG")
print("Saved PNG variant")
