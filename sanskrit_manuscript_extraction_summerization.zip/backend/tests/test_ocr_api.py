"""Backend API tests for Sanskrit Manuscript OCR (Vidyā).

Covers:
- /api/health
- /api/extract (image, translate=true/false, unsupported type, empty file)
- /api/translate (valid, empty)
"""
import io
import os
import pytest
import requests
from pathlib import Path
from dotenv import load_dotenv

# Load frontend .env so we get REACT_APP_BACKEND_URL when running via pytest
load_dotenv(Path("/app/frontend/.env"))

BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"

FIXTURE_JPG = "/app/test_fixtures/sanskrit_test.jpg"

# Reasonable timeout for LLM calls (Gemini can take 10-40s)
LLM_TIMEOUT = 180


@pytest.fixture(scope="session")
def session():
    s = requests.Session()
    return s


@pytest.fixture(scope="session")
def image_bytes():
    with open(FIXTURE_JPG, "rb") as f:
        return f.read()


# ---------- Health ----------
class TestHealth:
    def test_health_ok(self, session):
        r = session.get(f"{API}/health", timeout=15)
        assert r.status_code == 200
        data = r.json()
        assert data.get("status") == "ok"
        assert data.get("llm_configured") is True


# ---------- Extract endpoint ----------
class TestExtract:
    def test_extract_image_with_translate_true(self, session, image_bytes):
        files = {"file": ("sanskrit_test.jpg", image_bytes, "image/jpeg")}
        data = {"translate": "true"}
        r = session.post(f"{API}/extract", files=files, data=data, timeout=LLM_TIMEOUT)
        assert r.status_code == 200, f"Body: {r.text[:500]}"
        body = r.json()
        # Structural asserts
        for key in ("id", "sanskrit", "english", "translated", "filename", "created_at"):
            assert key in body, f"Missing key: {key}"
        # Content asserts
        assert isinstance(body["sanskrit"], str) and len(body["sanskrit"].strip()) > 0, \
            f"Sanskrit should be non-empty. Got: {body['sanskrit']!r}"
        assert isinstance(body["english"], str) and len(body["english"].strip()) > 0, \
            f"English should be non-empty when translate=true. Got: {body['english']!r}"
        assert body["translated"] is True
        assert body["filename"] == "sanskrit_test.jpg"
        # Devanagari codepoints in the sanskrit response
        has_devanagari = any("\u0900" <= ch <= "\u097F" for ch in body["sanskrit"])
        assert has_devanagari, f"Response 'sanskrit' should contain Devanagari chars. Got: {body['sanskrit'][:200]!r}"

    def test_extract_image_with_translate_false(self, session, image_bytes):
        files = {"file": ("sanskrit_test.jpg", image_bytes, "image/jpeg")}
        data = {"translate": "false"}
        r = session.post(f"{API}/extract", files=files, data=data, timeout=LLM_TIMEOUT)
        assert r.status_code == 200, f"Body: {r.text[:500]}"
        body = r.json()
        assert len(body["sanskrit"].strip()) > 0, "Sanskrit must be populated"
        assert body["english"].strip() == "", f"English should be empty. Got: {body['english']!r}"
        assert body["translated"] is False

    def test_extract_unsupported_mime(self, session):
        files = {"file": ("readme.txt", b"hello world", "text/plain")}
        data = {"translate": "false"}
        r = session.post(f"{API}/extract", files=files, data=data, timeout=30)
        assert r.status_code == 400
        assert "Unsupported" in r.text or "detail" in r.json()

    def test_extract_empty_file(self, session):
        files = {"file": ("empty.jpg", b"", "image/jpeg")}
        data = {"translate": "false"}
        r = session.post(f"{API}/extract", files=files, data=data, timeout=30)
        assert r.status_code == 400
        body = r.json()
        assert "Empty" in body.get("detail", "") or "empty" in body.get("detail", "").lower()


# ---------- Translate-only endpoint ----------
class TestTranslate:
    def test_translate_valid(self, session):
        payload = {"sanskrit": "सत्यमेव जयते।"}
        r = session.post(f"{API}/translate", json=payload, timeout=LLM_TIMEOUT)
        assert r.status_code == 200, f"Body: {r.text[:500]}"
        body = r.json()
        assert "english" in body
        eng = body["english"].strip()
        assert len(eng) > 0, f"English translation should not be empty. Got: {eng!r}"
        # Should be primarily ASCII/Latin
        latin_chars = sum(1 for ch in eng if ch.isascii() and ch.isalpha())
        assert latin_chars > 3, f"Translation should contain English words. Got: {eng!r}"

    def test_translate_empty_string(self, session):
        r = session.post(f"{API}/translate", json={"sanskrit": ""}, timeout=30)
        assert r.status_code == 400
        body = r.json()
        assert "empty" in body.get("detail", "").lower()

    def test_translate_whitespace_only(self, session):
        r = session.post(f"{API}/translate", json={"sanskrit": "   "}, timeout=30)
        assert r.status_code == 400
