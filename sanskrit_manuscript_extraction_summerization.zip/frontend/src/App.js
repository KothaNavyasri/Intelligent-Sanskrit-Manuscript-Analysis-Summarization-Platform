import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import LandingPage from "@/pages/LandingPage";
import ManuscriptsPage from "@/pages/ManuscriptsPage";
import ManuscriptDetailPage from "@/pages/ManuscriptDetailPage";
import DictionaryPage from "@/pages/DictionaryPage";
import StatsPage from "@/pages/StatsPage";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/manuscripts" element={<ManuscriptsPage />} />
          <Route path="/manuscripts/:id" element={<ManuscriptDetailPage />} />
          <Route path="/r/:id" element={<ManuscriptDetailPage />} />
          <Route path="/dictionary" element={<DictionaryPage />} />
          <Route path="/stats" element={<StatsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        <Footer />
      </BrowserRouter>
      <Toaster position="top-center" richColors />
    </div>
  );
}

export default App;
