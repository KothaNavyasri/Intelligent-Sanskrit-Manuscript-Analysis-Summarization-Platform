import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "sonner";
import { Loader2, Search, BookOpen, Sparkles } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function DictionaryPage() {
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("count");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lookingUp, setLookingUp] = useState({});

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${API}/dictionary`, {
        params: { q: q || undefined, sort },
      });
      setItems(data || []);
    } catch {
      toast.error("Failed to load dictionary.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sort]);

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const lookup = async (entry) => {
    setLookingUp((s) => ({ ...s, [entry.id]: true }));
    try {
      const { data } = await axios.post(`${API}/dictionary/lookup`, { id: entry.id });
      setItems((xs) => xs.map((x) => (x.id === entry.id ? { ...x, meaning: data.meaning } : x)));
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Lookup failed.");
    } finally {
      setLookingUp((s) => ({ ...s, [entry.id]: false }));
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-6 md:px-10 py-16">
      <div className="grid md:grid-cols-12 gap-8 items-end mb-10">
        <div className="md:col-span-8">
          <div className="font-ui text-[11px] uppercase tracking-[0.32em] text-muted-foreground mb-4">
            The Lexicon
          </div>
          <h1 className="font-display text-4xl md:text-5xl tracking-tight">
            Dictionary dataset.
          </h1>
          <p className="font-serif text-foreground/75 mt-3 max-w-xl">
            Every unique word your manuscripts have yielded, indexed with frequency and IAST.
            Tap <em>Look up</em> to fetch a scholarly English gloss on demand.
          </p>
        </div>
        <div className="md:col-span-4 flex gap-2">
          <div className="relative flex-1">
            <Search
              strokeWidth={1.5}
              className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              placeholder="Search Devanagari, IAST, meaning…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              data-testid="dictionary-search"
              className="pl-9 rounded-sm bg-card border-border font-serif"
            />
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            data-testid="dictionary-sort"
            className="rounded-sm border border-border bg-card px-3 font-ui text-[11px] uppercase tracking-[0.16em]"
          >
            <option value="count">Frequency</option>
            <option value="alpha">Alphabetical</option>
            <option value="recent">Recent</option>
          </select>
        </div>
      </div>

      <div className="paper-card overflow-hidden">
        {loading ? (
          <div className="p-12 flex items-center justify-center text-muted-foreground">
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Turning pages…
          </div>
        ) : items.length === 0 ? (
          <div className="p-16 text-center">
            <BookOpen strokeWidth={1.25} className="w-8 h-8 text-primary mx-auto mb-3" />
            <div className="font-display text-2xl">No words yet.</div>
            <p className="font-serif text-muted-foreground mt-2">
              Upload manuscripts to grow the lexicon.
            </p>
          </div>
        ) : (
          <table className="w-full border-collapse" data-testid="dictionary-table">
            <thead>
              <tr className="border-b border-border">
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  Devanagari
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  IAST
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  Count
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  English gloss
                </th>
              </tr>
            </thead>
            <tbody>
              {items.map((e) => (
                <tr
                  key={e.id}
                  className="border-b border-border last:border-b-0 hover:bg-muted/40 transition-colors"
                  data-testid="dictionary-row"
                >
                  <td className="px-4 py-3 font-sanskrit text-xl">{e.sanskrit || "—"}</td>
                  <td className="px-4 py-3 font-serif italic text-foreground/85">
                    {e.iast || "—"}
                  </td>
                  <td className="px-4 py-3 font-display text-lg text-primary">{e.count}</td>
                  <td className="px-4 py-3">
                    {e.meaning ? (
                      <span className="font-serif text-foreground/85">{e.meaning}</span>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => lookup(e)}
                        disabled={lookingUp[e.id]}
                        data-testid="dictionary-lookup-btn"
                        className="rounded-sm font-ui text-[10px] uppercase tracking-[0.18em]"
                      >
                        {lookingUp[e.id] ? (
                          <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                        ) : (
                          <Sparkles strokeWidth={1.5} className="w-3.5 h-3.5 mr-1.5" />
                        )}
                        Look up
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </section>
  );
}
