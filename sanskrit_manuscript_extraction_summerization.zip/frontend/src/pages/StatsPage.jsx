import { useEffect, useState } from "react";
import axios from "axios";
import {
  BarChart,
  Bar,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from "recharts";
import { Loader2, Gauge, BookOpen, ScrollText, Type, CheckCircle2, AlertTriangle } from "lucide-react";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const BUCKET_COLORS = {
  "0-40": "hsl(0 60% 42%)",
  "40-60": "hsl(30 75% 45%)",
  "60-80": "hsl(45 70% 42%)",
  "80-100": "hsl(140 45% 35%)",
};

function StatCard({ icon: Icon, label, value, sub }) {
  return (
    <div className="paper-card p-6">
      <div className="flex items-center gap-2 mb-3">
        <Icon strokeWidth={1.25} className="w-4 h-4 text-primary" />
        <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
          {label}
        </div>
      </div>
      <div className="font-display text-4xl tracking-tight text-foreground leading-none">
        {value}
      </div>
      {sub && (
        <div className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground mt-2">
          {sub}
        </div>
      )}
    </div>
  );
}

export default function StatsPage() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { data } = await axios.get(`${API}/stats`);
        if (alive) setStats(data);
      } catch {
        if (alive) setStats({ total_manuscripts: 0 });
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  if (loading) {
    return (
      <section className="max-w-7xl mx-auto px-6 md:px-10 py-16">
        <div className="p-16 flex items-center justify-center text-muted-foreground">
          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
          Compiling the archive…
        </div>
      </section>
    );
  }

  const buckets = stats?.confidence_buckets || {};
  const chartData = Object.entries(buckets).map(([range, count]) => ({ range, count }));
  const readablePct = stats?.total_manuscripts
    ? Math.round((stats.readable / stats.total_manuscripts) * 100)
    : 0;

  return (
    <section className="max-w-7xl mx-auto px-6 md:px-10 py-16" data-testid="stats-page">
      <div className="mb-10">
        <div className="font-ui text-[11px] uppercase tracking-[0.32em] text-muted-foreground mb-4">
          The Ledger
        </div>
        <h1 className="font-display text-4xl md:text-5xl tracking-tight">Dataset statistics.</h1>
        <p className="font-serif text-foreground/75 mt-3 max-w-2xl">
          The archive at a glance — OCR quality, readability, and lexicon growth over time.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        <StatCard
          icon={ScrollText}
          label="Manuscripts"
          value={stats?.total_manuscripts ?? 0}
          sub="Total in archive"
        />
        <StatCard
          icon={Gauge}
          label="Avg. OCR score"
          value={`${stats?.avg_confidence ?? 0}`}
          sub="Out of 100"
        />
        <StatCard
          icon={CheckCircle2}
          label="Readable"
          value={`${stats?.readable ?? 0}`}
          sub={`${readablePct}% of archive`}
        />
        <StatCard
          icon={BookOpen}
          label="Dictionary"
          value={`${stats?.dictionary_size ?? 0}`}
          sub={`${stats?.total_words_extracted ?? 0} words extracted`}
        />
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        <div className="paper-card p-6 lg:col-span-3" data-testid="ocr-quality-chart">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground mb-1">
                OCR quality distribution
              </div>
              <div className="font-display text-2xl">Confidence buckets</div>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <AlertTriangle strokeWidth={1.25} className="w-3.5 h-3.5" />
              <span className="font-ui text-[10px] uppercase tracking-[0.22em]">
                {stats?.non_readable ?? 0} non-readable
              </span>
            </div>
          </div>
          <div className="h-64 w-full" style={{ minHeight: 240 }}>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={chartData} margin={{ top: 10, right: 10, bottom: 10, left: 0 }}>
                <XAxis dataKey="range" tick={{ fill: "hsl(24 6% 25%)", fontFamily: "Inter", fontSize: 11 }} axisLine={{ stroke: "hsl(38 22% 80%)" }} tickLine={false} />
                <YAxis allowDecimals={false} tick={{ fill: "hsl(24 6% 25%)", fontFamily: "Inter", fontSize: 11 }} axisLine={{ stroke: "hsl(38 22% 80%)" }} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(40 20% 98%)",
                    border: "1px solid hsl(38 22% 80%)",
                    borderRadius: 2,
                    fontFamily: "EB Garamond, serif",
                  }}
                />
                <Bar dataKey="count" radius={[2, 2, 0, 0]}>
                  {chartData.map((d) => (
                    <Cell key={d.range} fill={BUCKET_COLORS[d.range]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="paper-card p-6 lg:col-span-2" data-testid="top-words-panel">
          <div className="mb-6">
            <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground mb-1">
              Most frequent words
            </div>
            <div className="font-display text-2xl">Top of the lexicon</div>
          </div>
          {stats?.top_words?.length ? (
            <ol className="divide-y divide-border">
              {stats.top_words.map((w, i) => (
                <li key={i} className="flex items-center justify-between py-2.5">
                  <div className="flex items-center gap-4 min-w-0">
                    <span className="font-display text-lg text-primary w-6 shrink-0">
                      {i + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="font-sanskrit text-lg truncate">{w.sanskrit || "—"}</div>
                      <div className="font-serif italic text-sm text-foreground/70 truncate">
                        {w.iast}
                      </div>
                    </div>
                  </div>
                  <div className="font-display text-lg text-foreground">{w.count}</div>
                </li>
              ))}
            </ol>
          ) : (
            <div className="text-center py-10">
              <Type strokeWidth={1.25} className="w-8 h-8 text-primary mx-auto mb-3" />
              <div className="font-serif text-muted-foreground">
                No words yet — upload a manuscript to begin.
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
