import { useEffect, useState, useRef, useCallback } from "react";
import axios from "axios";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import {
  Feather,
  ScrollText,
  Upload,
  Loader2,
  Languages,
  Sparkles,
  Info,
  BookOpen,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ACCEPTED_MIME, normalizeResult, pushHistory } from "@/lib/vidya";
import ResultView from "@/components/ResultView";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function Hero({ onStart }) {
  return (
    <section className="relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-10 pt-16 md:pt-24 pb-14 md:pb-20 grid md:grid-cols-12 gap-10 items-end">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: "easeOut" }}
          className="md:col-span-7"
        >
          <div className="font-ui text-[11px] uppercase tracking-[0.32em] text-muted-foreground mb-6 flex items-center gap-3">
            <span className="inline-block w-6 h-px bg-border" />
            An instrument for scholars
          </div>
          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl leading-[1.02] tracking-tight text-foreground">
            Read the <span className="italic text-primary">Devanagari.</span>
            <br />
            Understand the <span className="italic">Sanskrit.</span>
          </h1>
          <p className="mt-8 font-serif text-lg md:text-xl text-foreground/80 max-w-xl leading-relaxed">
            Upload a manuscript photograph or PDF. Vidyā extracts the original
            Sanskrit in Devanagari, renders it in Roman IAST, and translates it
            faithfully into English — folio by folio.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Button
              size="lg"
              onClick={onStart}
              data-testid="hero-start-btn"
              className="rounded-sm px-7 py-6 font-ui uppercase tracking-[0.18em] text-xs"
            >
              <Upload strokeWidth={1.5} className="w-4 h-4 mr-2" />
              Upload Manuscript
            </Button>
            <a
              href="#how"
              data-testid="hero-how-link"
              className="font-ui text-xs uppercase tracking-[0.22em] text-foreground/70 hover:text-primary transition-colors underline underline-offset-[6px] decoration-border"
            >
              How it works
            </a>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.0, delay: 0.15, ease: "easeOut" }}
          className="md:col-span-5 relative"
        >
          <div className="relative border border-border paper-card overflow-hidden">
            <img
              src="https://images.pexels.com/photos/15235034/pexels-photo-15235034.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Ancient manuscript in hand"
              className="w-full h-[380px] md:h-[460px] object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_bottom,transparent_40%,rgba(44,42,40,0.35))]" />
            <div className="absolute bottom-0 left-0 right-0 px-5 py-4 border-t border-border bg-card/85 backdrop-blur-sm">
              <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                Folio · circa 12th c.
              </div>
              <div className="font-display text-lg italic">“यत्र नार्यस्तु पूज्यन्ते…”</div>
            </div>
          </div>
        </motion.div>
      </div>
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="ink-rule" />
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { n: "I", title: "Upload", body: "Drop a photograph, scan, or PDF of your Sanskrit manuscript.", icon: Upload },
    { n: "II", title: "Extract", body: "Vidyā reads the folio and returns clean Devanagari + IAST.", icon: ScrollText },
    { n: "III", title: "Translate", body: "Translate to English and summarize with a single click.", icon: Languages },
  ];
  return (
    <section id="how" className="max-w-7xl mx-auto px-6 md:px-10 py-20">
      <div className="grid md:grid-cols-12 gap-10">
        <div className="md:col-span-4">
          <div className="font-ui text-[11px] uppercase tracking-[0.32em] text-muted-foreground mb-4">
            The Method
          </div>
          <h2 className="font-display text-4xl md:text-5xl tracking-tight">
            Three deliberate motions.
          </h2>
        </div>
        <div className="md:col-span-8 grid md:grid-cols-3 gap-6">
          {steps.map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.7, delay: i * 0.12 }}
              className="paper-card p-7"
              data-testid={`how-step-${s.n.toLowerCase()}`}
            >
              <div className="flex items-center justify-between mb-6">
                <div className="font-display text-2xl italic text-primary">{s.n}</div>
                <s.icon strokeWidth={1.25} className="w-5 h-5 text-foreground/70" />
              </div>
              <div className="font-display text-2xl mb-2">{s.title}</div>
              <p className="font-serif text-foreground/75 leading-relaxed">{s.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Dropzone({ onFile, disabled }) {
  const inputRef = useRef(null);
  const [active, setActive] = useState(false);
  const validate = (f) => {
    if (!f) return false;
    if (!ACCEPTED_MIME.includes(f.type)) {
      toast.error("Unsupported file. Use JPG, PNG, WEBP or PDF.");
      return false;
    }
    if (f.size > 20 * 1024 * 1024) {
      toast.error("File too large. Maximum 20MB.");
      return false;
    }
    return true;
  };
  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setActive(true);
      }}
      onDragLeave={() => setActive(false)}
      onDrop={(e) => {
        e.preventDefault();
        setActive(false);
        if (disabled) return;
        const f = e.dataTransfer.files?.[0];
        if (validate(f)) onFile(f);
      }}
      className={`relative border border-dashed transition-colors ${
        active ? "drop-active" : "border-border bg-card"
      } ${disabled ? "opacity-60 pointer-events-none" : ""}`}
      data-testid="upload-dropzone"
    >
      <input
        ref={inputRef}
        type="file"
        accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf"
        className="hidden"
        data-testid="file-input"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (validate(f)) onFile(f);
          e.target.value = "";
        }}
      />
      <div className="p-10 md:p-16 text-center flex flex-col items-center gap-5">
        <ScrollText strokeWidth={1.25} className="w-10 h-10 text-primary" />
        <div>
          <div className="font-display text-3xl md:text-4xl">Place your manuscript here.</div>
          <div className="font-serif text-foreground/70 mt-2">
            Drag a folio into the frame, or choose from your device.
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3 justify-center">
          <Button
            onClick={() => inputRef.current?.click()}
            data-testid="choose-file-btn"
            className="rounded-sm font-ui uppercase tracking-[0.18em] text-[11px] px-6 py-5"
          >
            Choose file
          </Button>
          <span className="font-ui text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
            JPG · PNG · WEBP · PDF · up to 20MB
          </span>
        </div>
      </div>
    </div>
  );
}

export default function LandingPage() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [translate, setTranslate] = useState(true);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const workspaceRef = useRef(null);

  const scrollHere = useCallback(() => {
    workspaceRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, []);

  useEffect(() => {
    if (!file || !file.type?.startsWith("image/")) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const submit = async () => {
    if (!file) return;
    setLoading(true);
    const form = new FormData();
    form.append("file", file);
    form.append("translate", translate ? "true" : "false");
    try {
      const { data } = await axios.post(`${API}/extract`, form, {
        headers: { "Content-Type": "multipart/form-data" },
        timeout: 240000,
      });
      const enriched = normalizeResult(data);
      setResult(enriched);
      pushHistory(enriched);
      toast.success(
        enriched.pages.length > 1
          ? `Read ${enriched.pages.length} pages successfully.`
          : "Manuscript read successfully.",
      );
    } catch (err) {
      const msg = err?.response?.data?.detail || err?.message || "Extraction failed.";
      toast.error(String(msg));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div data-testid="home">
      <Hero onStart={scrollHere} />
      <HowItWorks />
      <section
        id="workspace"
        ref={workspaceRef}
        className="max-w-7xl mx-auto px-6 md:px-10 py-16"
      >
        <div className="grid md:grid-cols-12 gap-8 items-end mb-8">
          <div className="md:col-span-8">
            <div className="font-ui text-[11px] uppercase tracking-[0.32em] text-muted-foreground mb-4">
              The Reading Desk
            </div>
            <h2 className="font-display text-4xl md:text-5xl tracking-tight">
              Bring a folio to the light.
            </h2>
          </div>
          <div className="md:col-span-4 flex md:justify-end items-center gap-4">
            <Label
              htmlFor="translate-toggle"
              className="font-ui text-[11px] uppercase tracking-[0.22em] text-foreground/80 cursor-pointer flex items-center gap-2"
            >
              <Languages strokeWidth={1.5} className="w-4 h-4" />
              Translate to English
            </Label>
            <Switch
              id="translate-toggle"
              checked={translate}
              onCheckedChange={setTranslate}
              data-testid="translate-toggle"
            />
          </div>
        </div>

        {!file && !result && <Dropzone onFile={setFile} disabled={loading} />}

        {file && !result && (
          <div className="paper-card p-6 md:p-8" data-testid="staged-file">
            <div className="grid md:grid-cols-12 gap-8 items-start">
              <div className="md:col-span-5">
                {preview ? (
                  <img src={preview} alt="preview" className="w-full h-auto border border-border" />
                ) : (
                  <div className="border border-border p-10 flex flex-col items-center gap-3 bg-muted/40">
                    <ScrollText strokeWidth={1.25} className="w-8 h-8 text-primary" />
                    <div className="font-display text-xl text-center">{file.name}</div>
                    <div className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                      PDF · {(file.size / 1024 / 1024).toFixed(2)} MB
                    </div>
                  </div>
                )}
              </div>
              <div className="md:col-span-7">
                <div className="font-display text-3xl leading-tight">Ready to be read.</div>
                <p className="font-serif text-foreground/75 mt-3 leading-relaxed">
                  Vidyā will inspect{" "}
                  <span className="italic text-foreground">{file.name}</span> and return the
                  Devanagari text{translate ? " with an English translation" : ""}.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Button
                    onClick={submit}
                    disabled={loading}
                    data-testid="extract-btn"
                    className="rounded-sm font-ui uppercase tracking-[0.18em] text-[11px] px-6 py-5"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Reading…
                      </>
                    ) : (
                      <>
                        <Sparkles strokeWidth={1.5} className="w-4 h-4 mr-2" />
                        Extract
                      </>
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setFile(null)}
                    disabled={loading}
                    data-testid="cancel-file-btn"
                    className="rounded-sm font-ui uppercase tracking-[0.18em] text-[11px] px-6 py-5"
                  >
                    Choose another
                  </Button>
                </div>
                <div className="mt-6 font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground inline-flex items-center gap-2">
                  <Info strokeWidth={1.5} className="w-3.5 h-3.5" />
                  Extraction may take 10–60 seconds; PDFs are processed page by page.
                </div>
              </div>
            </div>
          </div>
        )}

        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <ResultView
                result={result}
                onClose={() => {
                  setResult(null);
                  setFile(null);
                  scrollHere();
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </section>
    </div>
  );
}
