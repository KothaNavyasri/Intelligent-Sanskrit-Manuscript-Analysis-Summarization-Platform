import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  BookOpen,
  Gauge,
  Info,
  ClipboardCopy,
  FileDown,
  X,
  Link2,
  ChevronLeft,
  ChevronRight,
  ScrollText,
  Type,
  Sparkles,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import axios from "axios";
import { buildTextDump, downloadPdf, downloadText, escapeHtml } from "@/lib/vidya";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function PageThumbs({ pages, active, onSelect }) {
  if (pages.length <= 1) return null;
  return (
    <div className="border-b border-border bg-muted/30 px-4 py-3 overflow-x-auto">
      <div className="flex items-center gap-3" data-testid="page-thumbs">
        <span className="font-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground shrink-0 pr-2 border-r border-border">
          {pages.length} pages
        </span>
        {pages.map((p) => {
          const isActive = p.page_number === active;
          return (
            <button
              key={p.page_number}
              onClick={() => onSelect(p.page_number)}
              data-testid={`page-thumb-${p.page_number}`}
              className={`shrink-0 relative border transition-colors ${
                isActive ? "border-primary" : "border-border hover:border-foreground/40"
              }`}
              title={`Page ${p.page_number}`}
            >
              {p.image_data_url ? (
                <img
                  src={p.image_data_url}
                  alt={`page ${p.page_number}`}
                  className="h-16 w-12 object-cover bg-card"
                />
              ) : (
                <div className="h-16 w-12 flex items-center justify-center bg-card">
                  <ScrollText strokeWidth={1.25} className="w-4 h-4 text-primary" />
                </div>
              )}
              <div
                className={`absolute -bottom-2 left-1/2 -translate-x-1/2 font-ui text-[9px] uppercase tracking-[0.18em] px-1.5 py-0.5 ${
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border text-muted-foreground"
                }`}
              >
                {p.page_number}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function ResultView({ result, onClose, showSummarize = true, embedded = false }) {
  const pages = result.pages || [];
  const [activePage, setActivePage] = useState(pages[0]?.page_number || 1);
  const [showIast, setShowIast] = useState(false);
  const [summary, setSummary] = useState(result.summary || "");
  const [summarizing, setSummarizing] = useState(false);
  const navigate = useNavigate();

  const page = pages.find((p) => p.page_number === activePage) || pages[0];
  if (!page) return null;

  const conf = page.confidence || 0;
  const confTone =
    conf >= 80 ? "text-emerald-700" : conf >= 55 ? "text-amber-700" : "text-destructive";
  const hasPreview = Boolean(page.image_data_url);
  const hasIast = Boolean(page.iast);

  const goPrev = () => {
    const i = pages.findIndex((p) => p.page_number === activePage);
    if (i > 0) setActivePage(pages[i - 1].page_number);
  };
  const goNext = () => {
    const i = pages.findIndex((p) => p.page_number === activePage);
    if (i >= 0 && i < pages.length - 1) setActivePage(pages[i + 1].page_number);
  };

  const copy = async (text, label) => {
    try {
      await navigator.clipboard.writeText(text || "");
      toast.success(`${label} copied.`);
    } catch {
      toast.error("Copy failed.");
    }
  };

  const share = async () => {
    if (!result?.id) return;
    const url = `${window.location.origin}/manuscripts/${result.id}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Share link copied to clipboard.");
    } catch {
      toast.error(url);
    }
  };

  const summarize = async () => {
    if (!result?.id) return;
    setSummarizing(true);
    try {
      const { data } = await axios.post(`${API}/manuscripts/${result.id}/summarize`);
      setSummary(data.summary || "");
      toast.success("Summary generated.");
    } catch (e) {
      toast.error(e?.response?.data?.detail || "Summarize failed.");
    } finally {
      setSummarizing(false);
    }
  };

  return (
    <div className="paper-card">
      <div className="flex items-center justify-between px-6 py-4 border-b border-border flex-wrap gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <BookOpen strokeWidth={1.25} className="w-4 h-4 text-primary shrink-0" />
          <div className="font-display text-xl truncate">{result.filename}</div>
          <span
            data-testid="readable-badge"
            className={`font-ui text-[9px] uppercase tracking-[0.24em] px-2 py-1 border ${
              result.readable
                ? "border-emerald-700/40 text-emerald-800 bg-emerald-50"
                : "border-destructive/40 text-destructive bg-destructive/10"
            }`}
          >
            {result.readable ? "Readable" : "Non-readable"}
          </span>
          <span className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground hidden md:inline">
            {new Date(result.created_at).toLocaleString()}
          </span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div
            className="paper-card px-3 py-1.5 flex items-center gap-2"
            data-testid="confidence-badge"
            title={page.notes || "OCR confidence"}
          >
            <Gauge strokeWidth={1.5} className={`w-3.5 h-3.5 ${confTone}`} />
            <span className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              OCR
            </span>
            <span className={`font-display text-lg leading-none ${confTone}`}>{conf}</span>
            <span className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              /100
            </span>
          </div>
          {hasIast && (
            <Button
              variant={showIast ? "default" : "outline"}
              size="sm"
              data-testid="iast-toggle-btn"
              onClick={() => setShowIast((v) => !v)}
              className="rounded-sm font-ui text-[10px] uppercase tracking-[0.2em]"
            >
              <Type strokeWidth={1.5} className="w-3.5 h-3.5 mr-1.5" />
              IAST
            </Button>
          )}
          {showSummarize && (
            <Button
              variant="outline"
              size="sm"
              onClick={summarize}
              disabled={summarizing}
              data-testid="summarize-btn"
              className="rounded-sm font-ui text-[10px] uppercase tracking-[0.2em]"
            >
              {summarizing ? (
                <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
              ) : (
                <Sparkles strokeWidth={1.5} className="w-3.5 h-3.5 mr-1.5" />
              )}
              Summarize
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            data-testid="share-link-btn"
            onClick={share}
            className="rounded-sm font-ui text-[10px] uppercase tracking-[0.2em]"
          >
            <Link2 strokeWidth={1.5} className="w-3.5 h-3.5 mr-1.5" />
            Share
          </Button>
          <Button
            variant="outline"
            size="sm"
            data-testid="download-txt-btn"
            onClick={() =>
              downloadText(
                `${(result.filename || "manuscript").replace(/\.[^.]+$/, "")}.txt`,
                buildTextDump({ ...result, summary }),
              )
            }
            className="rounded-sm font-ui text-[10px] uppercase tracking-[0.2em]"
          >
            <FileDown strokeWidth={1.5} className="w-3.5 h-3.5 mr-1.5" />
            .txt
          </Button>
          <Button
            variant="outline"
            size="sm"
            data-testid="download-pdf-btn"
            onClick={() => downloadPdf({ ...result, summary })}
            className="rounded-sm font-ui text-[10px] uppercase tracking-[0.2em]"
          >
            <FileDown strokeWidth={1.5} className="w-3.5 h-3.5 mr-1.5" />
            PDF
          </Button>
          {onClose && (
            <Button
              variant="ghost"
              size="sm"
              data-testid="close-result-btn"
              onClick={onClose}
              className="rounded-sm"
              aria-label="Close"
            >
              <X strokeWidth={1.5} className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      <PageThumbs pages={pages} active={activePage} onSelect={setActivePage} />

      {page.notes && (
        <div className="px-6 py-2.5 border-b border-border bg-muted/40 flex items-center gap-2">
          <Info strokeWidth={1.5} className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="font-serif text-sm text-foreground/75 italic">{page.notes}</span>
        </div>
      )}

      <div className="grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-border">
        <div className="p-6 md:p-8" data-testid="manuscript-panel">
          <div className="flex items-center justify-between mb-4">
            <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              Folio · {pages.length > 1 ? `Page ${page.page_number}` : "Original"}
            </div>
            {hasPreview && (
              <a
                href={page.image_data_url}
                target="_blank"
                rel="noreferrer"
                data-testid="open-original-link"
                className="font-ui text-[10px] uppercase tracking-[0.22em] text-foreground/70 hover:text-primary transition-colors"
              >
                Open full ↗
              </a>
            )}
          </div>
          {hasPreview ? (
            <div className="border border-border overflow-hidden bg-muted/30">
              <img
                src={page.image_data_url}
                alt={`page ${page.page_number}`}
                className="w-full h-auto max-h-[520px] object-contain bg-[hsl(var(--muted))]"
                data-testid="manuscript-image"
              />
            </div>
          ) : (
            <div className="border border-border p-10 flex flex-col items-center gap-3 bg-muted/40 min-h-[220px] justify-center">
              <ScrollText strokeWidth={1.25} className="w-8 h-8 text-primary" />
              <div className="font-display text-lg text-center">{result.filename}</div>
              <div className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Preview unavailable
              </div>
            </div>
          )}
          {pages.length > 1 && (
            <div className="mt-4 flex items-center justify-between">
              <button
                onClick={goPrev}
                disabled={activePage === pages[0].page_number}
                data-testid="prev-page-btn"
                className="font-ui text-[10px] uppercase tracking-[0.22em] text-foreground/70 hover:text-primary transition-colors disabled:opacity-40 inline-flex items-center gap-1"
              >
                <ChevronLeft strokeWidth={1.5} className="w-3.5 h-3.5" />
                Prev
              </button>
              <span className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                {page.page_number} / {pages.length}
              </span>
              <button
                onClick={goNext}
                disabled={activePage === pages[pages.length - 1].page_number}
                data-testid="next-page-btn"
                className="font-ui text-[10px] uppercase tracking-[0.22em] text-foreground/70 hover:text-primary transition-colors disabled:opacity-40 inline-flex items-center gap-1"
              >
                Next
                <ChevronRight strokeWidth={1.5} className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        <div className="p-6 md:p-8" data-testid="sanskrit-panel">
          <div className="flex items-center justify-between mb-4">
            <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              Sanskrit · {showIast && hasIast ? "IAST" : "Devanagari"}
            </div>
            <button
              onClick={() =>
                copy(showIast && hasIast ? page.iast : page.sanskrit, showIast ? "IAST" : "Sanskrit")
              }
              data-testid="copy-sanskrit-btn"
              className="font-ui text-[10px] uppercase tracking-[0.22em] text-foreground/70 hover:text-primary transition-colors inline-flex items-center gap-1.5"
            >
              <ClipboardCopy strokeWidth={1.5} className="w-3.5 h-3.5" />
              Copy
            </button>
          </div>
          {showIast && hasIast ? (
            <div
              className="font-serif italic text-lg leading-relaxed whitespace-pre-wrap text-foreground"
              data-testid="iast-body"
            >
              {page.iast}
            </div>
          ) : (
            <div className="sanskrit-body whitespace-pre-wrap text-foreground">
              {page.sanskrit || (
                <span className="text-muted-foreground italic">No Devanagari detected.</span>
              )}
            </div>
          )}
          {!showIast && hasIast && (
            <div className="mt-6 pt-4 border-t border-dashed border-border">
              <div className="font-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground mb-2">
                IAST · Roman
              </div>
              <div
                className="font-serif italic text-base leading-relaxed whitespace-pre-wrap text-foreground/75"
                data-testid="iast-inline"
              >
                {page.iast}
              </div>
            </div>
          )}
        </div>

        <div className="p-6 md:p-8" data-testid="english-panel">
          <div className="flex items-center justify-between mb-4">
            <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              English · Translation
            </div>
            {page.english && (
              <button
                onClick={() => copy(page.english, "English")}
                data-testid="copy-english-btn"
                className="font-ui text-[10px] uppercase tracking-[0.22em] text-foreground/70 hover:text-primary transition-colors inline-flex items-center gap-1.5"
              >
                <ClipboardCopy strokeWidth={1.5} className="w-3.5 h-3.5" />
                Copy
              </button>
            )}
          </div>
          <div className="font-serif text-lg leading-relaxed whitespace-pre-wrap text-foreground">
            {page.english ? (
              page.english
            ) : (
              <span className="text-muted-foreground italic">
                Translation not requested for this page.
              </span>
            )}
          </div>
        </div>
      </div>

      {summary && (
        <div className="border-t border-border px-6 py-6 md:px-8 bg-muted/40" data-testid="summary-panel">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles strokeWidth={1.5} className="w-4 h-4 text-primary" />
            <div className="font-ui text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
              Scholar’s summary
            </div>
          </div>
          <div className="font-serif text-lg leading-relaxed text-foreground">{summary}</div>
        </div>
      )}
    </div>
  );
}
