import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import { Loader2, ArrowLeft } from "lucide-react";
import { normalizeResult } from "@/lib/vidya";
import ResultView from "@/components/ResultView";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function ManuscriptDetailPage() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const { data: d } = await axios.get(`${API}/manuscripts/${id}`);
        if (alive) setData(normalizeResult(d));
      } catch (e) {
        if (alive) setError(e?.response?.data?.detail || "Manuscript not found.");
      }
    })();
    return () => {
      alive = false;
    };
  }, [id]);

  return (
    <section className="max-w-7xl mx-auto px-6 md:px-10 py-12">
      <div className="mb-6">
        <Link
          to="/manuscripts"
          data-testid="back-to-manuscripts"
          className="font-ui text-[11px] uppercase tracking-[0.22em] text-foreground/70 hover:text-primary inline-flex items-center gap-2 transition-colors"
        >
          <ArrowLeft strokeWidth={1.5} className="w-3.5 h-3.5" />
          Back to archive
        </Link>
      </div>
      {!data && !error && (
        <div className="p-16 flex items-center justify-center text-muted-foreground">
          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
          Fetching folio…
        </div>
      )}
      {error && (
        <div className="paper-card p-10 text-center">
          <div className="font-display text-2xl text-destructive">{error}</div>
          <p className="font-serif text-muted-foreground mt-2">
            The manuscript may have been deleted, or the link is incorrect.
          </p>
        </div>
      )}
      {data && <ResultView result={data} />}
    </section>
  );
}
