import { Feather } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function Footer() {
  return (
    <footer className="border-t border-border/70 mt-14">
      <div className="max-w-7xl mx-auto px-6 md:px-10 py-10 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Feather strokeWidth={1.25} className="w-4 h-4 text-primary" />
          <span className="font-display text-lg">Vidyā</span>
          <Separator orientation="vertical" className="h-4 mx-3" />
          <span className="font-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
            A scholar’s companion
          </span>
        </div>
        <div className="font-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          Manuscripts · Dictionary · Statistics
        </div>
      </div>
    </footer>
  );
}
