import { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Loader2, Search, Trash2, ExternalLink, BookOpen } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/vidya";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const TABS = [
  { key: "all", label: "All" },
  { key: "readable", label: "Readable" },
  { key: "non_readable", label: "Non-readable" },
];

export default function ManuscriptsPage() {
  const [tab, setTab] = useState("all");
  const [q, setQ] = useState("");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${API}/manuscripts`, {
        params: { readable: tab, q: q || undefined },
      });
      setItems(data || []);
    } catch (e) {
      toast.error("Failed to load manuscripts.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  const remove = async (id) => {
    if (!window.confirm("Delete this manuscript from the database?")) return;
    try {
      await axios.delete(`${API}/manuscripts/${id}`);
      toast.success("Manuscript deleted.");
      setItems((xs) => xs.filter((x) => x.id !== id));
    } catch {
      toast.error("Delete failed.");
    }
  };

  const totalReadable = useMemo(() => items.filter((i) => i.readable).length, [items]);

  return (
    <section className="max-w-7xl mx-auto px-6 md:px-10 py-16">
      <div className="grid md:grid-cols-12 gap-8 items-end mb-10">
        <div className="md:col-span-8">
          <div className="font-ui text-[11px] uppercase tracking-[0.32em] text-muted-foreground mb-4">
            The Archive
          </div>
          <h1 className="font-display text-4xl md:text-5xl tracking-tight">
            Manuscript database.
          </h1>
          <p className="font-serif text-foreground/75 mt-3 max-w-xl">
            Every folio you have read is preserved here, classified by legibility and searchable
            across Devanagari, IAST, and English.
          </p>
        </div>
        <div className="md:col-span-4">
          <div className="relative">
            <Search
              strokeWidth={1.5}
              className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              placeholder="Search filename or text…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              data-testid="manuscripts-search"
              className="pl-9 rounded-sm bg-card border-border font-serif"
            />
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1 border-b border-border mb-6">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            data-testid={`tab-${t.key}`}
            className={`font-ui text-[11px] uppercase tracking-[0.22em] px-4 py-3 border-b -mb-px transition-colors ${
              tab === t.key
                ? "border-primary text-primary"
                : "border-transparent text-foreground/70 hover:text-primary"
            }`}
          >
            {t.label}
          </button>
        ))}
        <div className="ml-auto font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground pr-2">
          {items.length} entries · {totalReadable} readable
        </div>
      </div>

      <div className="paper-card overflow-hidden">
        {loading ? (
          <div className="p-12 flex items-center justify-center text-muted-foreground">
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Reading the archive…
          </div>
        ) : items.length === 0 ? (
          <div className="p-16 text-center">
            <BookOpen strokeWidth={1.25} className="w-8 h-8 text-primary mx-auto mb-3" />
            <div className="font-display text-2xl">No manuscripts yet.</div>
            <p className="font-serif text-muted-foreground mt-2">
              Upload a folio from the{" "}
              <Link to="/" className="text-primary underline underline-offset-4">
                Reading Desk
              </Link>{" "}
              to begin the archive.
            </p>
          </div>
        ) : (
          <table className="w-full border-collapse" data-testid="manuscripts-table">
            <thead>
              <tr className="border-b border-border">
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  Folio
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  Name · Date
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  Pages
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  Words
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  OCR
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-left px-4 py-3">
                  Class
                </th>
                <th className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground text-right px-4 py-3">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {items.map((it) => (
                <tr
                  key={it.id}
                  className="border-b border-border last:border-b-0 hover:bg-muted/40 transition-colors"
                  data-testid="manuscripts-row"
                >
                  <td className="px-4 py-3">
                    {it.thumbnail ? (
                      <img
                        src={it.thumbnail}
                        alt=""
                        className="h-14 w-11 object-cover border border-border"
                      />
                    ) : (
                      <div className="h-14 w-11 flex items-center justify-center border border-border bg-card">
                        <BookOpen strokeWidth={1.25} className="w-4 h-4 text-primary" />
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3 min-w-0">
                    <Link
                      to={`/manuscripts/${it.id}`}
                      className="font-display text-lg truncate block hover:text-primary transition-colors"
                    >
                      {it.filename}
                    </Link>
                    <div className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                      {formatDate(it.created_at)}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-serif">{it.pages_count}</td>
                  <td className="px-4 py-3 font-serif">{it.word_count}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`font-display text-lg ${
                        it.confidence >= 80
                          ? "text-emerald-700"
                          : it.confidence >= 55
                            ? "text-amber-700"
                            : "text-destructive"
                      }`}
                    >
                      {it.confidence}
                    </span>
                    <span className="font-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground ml-1">
                      /100
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`font-ui text-[9px] uppercase tracking-[0.22em] px-2 py-1 border ${
                        it.readable
                          ? "border-emerald-700/40 text-emerald-800 bg-emerald-50"
                          : "border-destructive/40 text-destructive bg-destructive/10"
                      }`}
                      data-testid={it.readable ? "row-readable" : "row-non-readable"}
                    >
                      {it.readable ? "Readable" : "Non-readable"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <Link
                      to={`/manuscripts/${it.id}`}
                      data-testid="open-manuscript-btn"
                      className="font-ui text-[10px] uppercase tracking-[0.22em] text-foreground/70 hover:text-primary transition-colors inline-flex items-center gap-1 mr-3"
                    >
                      Open <ExternalLink strokeWidth={1.5} className="w-3.5 h-3.5" />
                    </Link>
                    <button
                      onClick={() => remove(it.id)}
                      data-testid="delete-manuscript-btn"
                      className="font-ui text-[10px] uppercase tracking-[0.22em] text-foreground/70 hover:text-destructive transition-colors inline-flex items-center gap-1"
                    >
                      <Trash2 strokeWidth={1.5} className="w-3.5 h-3.5" /> Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </section>
  );
}
