# Vidyā — Sanskrit Manuscript OCR & Translator

## Original Problem Statement
Users upload manuscripts or images; the app extracts Sanskrit (Devanagari) text and optionally translates to English. Iteration 2 expanded scope to: readable/non-readable classification, dictionary dataset of extracted words, dataset statistics, manuscript database page, per-page PDF, IAST transliteration, shareable permalinks, and manuscript summarization.

## User Choices
- OCR + Translation engine: **Gemini 3 Flash** (via emergentintegrations, `EMERGENT_LLM_KEY`)
- Uploads: **Images (JPG/PNG/WEBP) + multi-page PDF** (up to 20 pages, rendered via PyMuPDF)
- Auth: **No login** (public tool)
- Extras: Download .txt & PDF, side-by-side view, local-storage recent readings, share link
- Design: **Scholarly parchment / minimalist** (Cormorant + EB Garamond + Tiro Devanagari Sanskrit, terracotta accent, no gradients)

## Architecture

### Backend (`/app/backend/server.py`)
- FastAPI + MongoDB (motor) + PyMuPDF + emergentintegrations
- Endpoints (all under `/api`):
  - `GET /health` — LLM key check
  - `POST /extract` — multipart upload; runs Gemini 3 Flash per page (concurrent, sem=3); returns pages[] with `sanskrit`, `iast`, `english`, `confidence`, `notes`, `image_data_url`; plus aggregates `readable` (avg conf ≥ 60), `word_count`, top-level joined text; persists to `db.extractions` and upserts unique words to `db.dictionary`.
  - `POST /translate` — Devanagari → English on demand
  - `GET /manuscripts?readable=all|readable|non_readable&q=` — list w/ thumbnails
  - `GET /manuscripts/{id}` — full ExtractResponse (permalink source)
  - `GET /extraction/{id}` — legacy alias
  - `DELETE /manuscripts/{id}` — remove doc + clean dictionary refs
  - `POST /manuscripts/{id}/summarize` — Gemini scholarly summary
  - `GET /dictionary?q=&sort=count|alpha|recent&limit=` — extracted words w/ counts + optional English gloss
  - `POST /dictionary/lookup` — Gemini English gloss for a specific word (Monier-Williams-style prompt)
  - `GET /stats` — total_manuscripts, readable/non_readable, avg_confidence, confidence_buckets, dictionary_size, top_words

### Frontend (`/app/frontend/src/*`)
- React + Tailwind + shadcn/ui + framer-motion + recharts
- Router with 5 routes: `/` (Landing), `/manuscripts`, `/manuscripts/:id` (and `/r/:id` permalink), `/dictionary`, `/stats`
- Modular files:
  - `App.js`, `components/NavBar.jsx`, `components/Footer.jsx`, `components/ResultView.jsx`
  - `pages/LandingPage.jsx` — hero + HowItWorks + Reading Desk (dropzone → staged file → ResultView)
  - `pages/ManuscriptsPage.jsx` — table with Readable/Non-readable tabs, search, open, delete
  - `pages/ManuscriptDetailPage.jsx` — full ResultView from permalink
  - `pages/DictionaryPage.jsx` — searchable/sortable word table + on-demand gloss lookup
  - `pages/StatsPage.jsx` — 4 stat cards + Recharts OCR quality bar chart + top words
  - `lib/vidya.js` — history, PDF export, .txt export, normalizeResult
- Fonts: Cormorant Garamond (display), EB Garamond (body), Tiro Devanagari Sanskrit (Devanagari), Inter (UI labels)
- Palette: parchment #F6F4EE / ink #2C2A28 / terracotta #B25E29; no gradients; 1px borders; paper grain overlay

## User Personas
1. Sanskrit scholar/student — batches of folios, needs faithful Devanagari + IAST + English + dictionary.
2. Archive volunteer — multi-page PDFs, wants filterable readable/non-readable tables.
3. Curious layperson — snap a photo, get gloss + summary.

## Implemented (major milestones)
- ✅ Extraction with Gemini 3 Flash (Devanagari + IAST + English + confidence + notes)
- ✅ Per-page PDF rendering (PyMuPDF, 140dpi, max 20 pages) with per-page thumbnails/nav
- ✅ IAST transliteration column + toggle
- ✅ Readable vs Non-readable classification (conf ≥ 60 → readable)
- ✅ Dataset statistics page with OCR quality buckets + top words + dictionary growth
- ✅ Manuscript database page with search + tabs + open/delete
- ✅ Dictionary page auto-populated from every extraction (unique word upserts) with on-demand gloss lookup
- ✅ Shareable permalink (`/manuscripts/:id`) and `/r/:id`
- ✅ Manuscript summarize endpoint + panel
- ✅ Full test suite: 21 pytest cases (iteration_1+iteration_2), Playwright E2E; all pass

## Backlog / P1
- Line-level highlighting: hover a Sanskrit line to highlight the manuscript region
- IAST-to-Devanagari reverse input for scholars typing in Roman
- Batch upload with async queue
- Export manuscript-level dictionary as CSV/JSON
- Compare-two-manuscripts view

## Backlog / P2
- Dark parchment mode
- Additional Indic scripts (Grantha, Sharada, Brahmi)
- Basic sandhi / pada split visualization
