from fastapi import FastAPI, APIRouter, UploadFile, File, Form, HTTPException, Query
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import re
import base64
import logging
import tempfile
import uuid
import json
import asyncio
from pathlib import Path
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime, timezone

import fitz  # PyMuPDF

from emergentintegrations.llm.chat import (
    LlmChat,
    UserMessage,
    FileContentWithMimeType,
)

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

EMERGENT_LLM_KEY = os.environ.get("EMERGENT_LLM_KEY")

app = FastAPI(title="Vidyā · Sanskrit Manuscript OCR")
api_router = APIRouter(prefix="/api")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

ALLOWED_IMAGE_TYPES = {
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
}
ALLOWED_PDF_TYPES = {"application/pdf": ".pdf"}
MAX_PDF_PAGES = 20
READABLE_THRESHOLD = 60  # confidence >= 60 -> readable

# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _build_prompt(translate: bool, page_hint: Optional[str] = None) -> str:
    tail = (
        'Respond STRICTLY as a JSON object with keys: '
        '"sanskrit" (Devanagari, preserve line breaks), '
        '"iast" (IAST Roman transliteration of the same, with diacritics like ā ī ū ṛ ṝ ḷ ṃ ḥ ś ṣ ṭ ḍ ṇ ñ), '
        '"english" (%s), '
        '"confidence" (integer 0-100 for OCR accuracy), '
        '"notes" (one short sentence on legibility). '
        "No markdown fences, no commentary outside JSON."
    ) % ("faithful English translation" if translate else 'empty string ""')
    head = (
        "You are an expert Sanskrit paleographer"
        + (" and translator" if translate else "")
        + ". Carefully examine the attached manuscript image"
        + (f" ({page_hint})" if page_hint else "")
        + ". Extract every visible Sanskrit/Devanagari character as accurately as possible, "
        "preserving line breaks. If the script is unclear, provide your best reading.\n\n"
    )
    return head + tail


def _parse_llm_json(raw: str) -> dict:
    if not raw:
        return {}
    text = str(raw).strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    return {"sanskrit": text}


def _new_chat(system_message: str) -> LlmChat:
    return LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=str(uuid.uuid4()),
        system_message=system_message,
    ).with_model("gemini", "gemini-3-flash-preview")


async def _run_gemini_on_image(
    image_bytes: bytes, mime_type: str, translate: bool, page_hint: Optional[str] = None
) -> dict:
    suffix = ".jpg" if "jpeg" in mime_type else (".png" if "png" in mime_type else ".webp")
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(image_bytes)
    tmp.flush()
    tmp.close()
    try:
        chat = _new_chat(
            "You are a scholarly assistant specialized in reading historical Sanskrit "
            "manuscripts in Devanagari script and translating them into English."
        )
        file_content = FileContentWithMimeType(file_path=tmp.name, mime_type=mime_type)
        prompt = _build_prompt(translate, page_hint)
        raw = await chat.send_message(UserMessage(text=prompt, file_contents=[file_content]))
        return _parse_llm_json(raw)
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            pass


def _render_pdf_pages(pdf_bytes: bytes, dpi: int = 140):
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    zoom = dpi / 72.0
    mat = fitz.Matrix(zoom, zoom)
    out = []
    for i, page in enumerate(doc):
        if i >= MAX_PDF_PAGES:
            break
        pix = page.get_pixmap(matrix=mat, alpha=False)
        out.append((pix.tobytes("jpeg"), "image/jpeg"))
    doc.close()
    return out


def _to_data_url(image_bytes: bytes, mime_type: str) -> str:
    return f"data:{mime_type};base64,{base64.b64encode(image_bytes).decode('ascii')}"


def _clamp_conf(v) -> int:
    try:
        n = int(v or 0)
    except (TypeError, ValueError):
        n = 0
    return max(0, min(100, n))


# Tokenize Sanskrit (Devanagari) + IAST into word pairs, aligned by position when possible
_DEV_WORD_RE = re.compile(r"[\u0900-\u097F]+")
_IAST_WORD_RE = re.compile(r"[A-Za-zĀāĪīŪūṚṛṜṝḶḷṂṃḤḥŚśṢṣṬṭḌḍṆṇÑñ]+")


def _tokenize_pair(sanskrit: str, iast: str) -> list[dict]:
    dev_words = _DEV_WORD_RE.findall(sanskrit or "")
    iast_words = _IAST_WORD_RE.findall(iast or "")
    pairs = []
    seen = set()
    for i, w in enumerate(dev_words):
        iw = iast_words[i] if i < len(iast_words) else ""
        key = w
        if key in seen:
            continue
        seen.add(key)
        pairs.append({"sanskrit": w, "iast": iw})
    # If IAST-only (no Devanagari), still index by iast
    if not pairs and iast_words:
        for w in iast_words:
            if w.lower() in seen:
                continue
            seen.add(w.lower())
            pairs.append({"sanskrit": "", "iast": w})
    return pairs


# ------------------------------------------------------------------
# Models
# ------------------------------------------------------------------


class PageResult(BaseModel):
    page_number: int
    sanskrit: str = ""
    iast: str = ""
    english: str = ""
    confidence: int = 0
    notes: str = ""
    image_data_url: str = ""


class ExtractResponse(BaseModel):
    id: str
    filename: str
    translated: bool
    created_at: str
    pages: List[PageResult]
    sanskrit: str
    iast: str
    english: str
    confidence: int
    notes: str
    readable: bool = True
    word_count: int = 0
    summary: str = ""


class ManuscriptSummary(BaseModel):
    id: str
    filename: str
    created_at: str
    translated: bool
    confidence: int
    readable: bool
    pages_count: int
    word_count: int
    thumbnail: str = ""  # first-page image_data_url


class TranslateOnlyRequest(BaseModel):
    sanskrit: str


class DictionaryEntry(BaseModel):
    id: str
    sanskrit: str
    iast: str
    count: int
    meaning: str = ""
    manuscripts: List[str] = []
    created_at: str


class DictionaryLookupRequest(BaseModel):
    id: Optional[str] = None
    sanskrit: Optional[str] = None
    iast: Optional[str] = None


# ------------------------------------------------------------------
# Health / root
# ------------------------------------------------------------------


@api_router.get("/")
async def root():
    return {"message": "Vidyā Sanskrit Manuscript OCR API"}


@api_router.get("/health")
async def health():
    return {"status": "ok", "llm_configured": bool(EMERGENT_LLM_KEY)}


# ------------------------------------------------------------------
# Extract
# ------------------------------------------------------------------


def _build_response_dict(
    record_id: str, filename: str, translate: bool, pages: List[PageResult]
) -> dict:
    sanskrit_joined = "\n\n".join(p.sanskrit for p in pages if p.sanskrit).strip()
    iast_joined = "\n\n".join(p.iast for p in pages if p.iast).strip()
    english_joined = "\n\n".join(p.english for p in pages if p.english).strip()
    confs = [p.confidence for p in pages if p.confidence]
    avg_conf = int(sum(confs) / len(confs)) if confs else 0
    notes = pages[0].notes if pages else ""
    word_count = len(_DEV_WORD_RE.findall(sanskrit_joined)) or len(
        _IAST_WORD_RE.findall(iast_joined)
    )
    return {
        "id": record_id,
        "filename": filename,
        "translated": bool(translate) and bool(english_joined),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "pages": [p.model_dump() for p in pages],
        "sanskrit": sanskrit_joined,
        "iast": iast_joined,
        "english": english_joined,
        "confidence": avg_conf,
        "notes": notes,
        "readable": avg_conf >= READABLE_THRESHOLD,
        "word_count": word_count,
        "summary": "",
    }


async def _upsert_dictionary_words(pages: List[PageResult], manuscript_id: str):
    seen = set()
    now = datetime.now(timezone.utc).isoformat()
    for p in pages:
        pairs = _tokenize_pair(p.sanskrit, p.iast)
        for pair in pairs:
            key = pair["sanskrit"] or pair["iast"].lower()
            if not key or key in seen:
                continue
            seen.add(key)
            filt = (
                {"sanskrit": pair["sanskrit"]}
                if pair["sanskrit"]
                else {"sanskrit": "", "iast_lower": pair["iast"].lower()}
            )
            existing = await db.dictionary.find_one(filt)
            if existing:
                await db.dictionary.update_one(
                    {"_id": existing["_id"]},
                    {
                        "$inc": {"count": 1},
                        "$addToSet": {"manuscripts": manuscript_id},
                        "$set": {"iast": existing.get("iast") or pair["iast"]},
                    },
                )
            else:
                await db.dictionary.insert_one(
                    {
                        "id": str(uuid.uuid4()),
                        "sanskrit": pair["sanskrit"],
                        "iast": pair["iast"],
                        "iast_lower": (pair["iast"] or "").lower(),
                        "count": 1,
                        "meaning": "",
                        "manuscripts": [manuscript_id],
                        "created_at": now,
                    }
                )


@api_router.post("/extract", response_model=ExtractResponse)
async def extract_manuscript(
    file: UploadFile = File(...),
    translate: bool = Form(False),
):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(status_code=500, detail="LLM key not configured on server.")

    content_type = (file.content_type or "").lower()
    is_image = content_type in ALLOWED_IMAGE_TYPES
    is_pdf = content_type in ALLOWED_PDF_TYPES
    if not (is_image or is_pdf):
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type: {content_type}. Allowed: JPG, PNG, WEBP, PDF.",
        )

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Empty file.")

    page_images = []
    if is_image:
        page_images.append((data, content_type, 1))
    else:
        try:
            rendered = _render_pdf_pages(data)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Failed to read PDF: {e}")
        if not rendered:
            raise HTTPException(status_code=400, detail="PDF contains no pages.")
        for idx, (b, m) in enumerate(rendered, start=1):
            page_images.append((b, m, idx))

    total_pages = len(page_images)

    async def process_page(item):
        img_bytes, mime, pnum = item
        hint = f"page {pnum} of {total_pages}" if total_pages > 1 else None
        try:
            parsed = await _run_gemini_on_image(img_bytes, mime, translate, hint)
        except Exception as e:
            logger.exception(f"Page {pnum} failed")
            parsed = {"sanskrit": "", "english": "", "iast": "", "confidence": 0, "notes": f"Error: {e}"}
        return PageResult(
            page_number=pnum,
            sanskrit=(parsed.get("sanskrit") or "").strip(),
            iast=(parsed.get("iast") or "").strip(),
            english=(parsed.get("english") or "").strip(),
            confidence=_clamp_conf(parsed.get("confidence")),
            notes=(parsed.get("notes") or "").strip(),
            image_data_url=_to_data_url(img_bytes, mime),
        )

    sem = asyncio.Semaphore(3)

    async def bounded(it):
        async with sem:
            return await process_page(it)

    pages = await asyncio.gather(*(bounded(it) for it in page_images))
    pages = sorted(pages, key=lambda p: p.page_number)

    record_id = str(uuid.uuid4())
    doc = _build_response_dict(record_id, file.filename or "manuscript", translate, pages)

    try:
        await db.extractions.insert_one({**doc})
        await _upsert_dictionary_words(pages, record_id)
    except Exception as e:
        logger.warning(f"DB persist failed (non-fatal): {e}")

    return ExtractResponse(**doc)


@api_router.post("/translate")
async def translate_only(payload: TranslateOnlyRequest):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(status_code=500, detail="LLM key not configured on server.")
    text = (payload.sanskrit or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="Sanskrit text is empty.")
    try:
        chat = _new_chat(
            "You are a scholarly Sanskrit-to-English translator. "
            "Return faithful, readable English translations of Devanagari Sanskrit."
        )
        prompt = (
            "Translate the following Sanskrit (Devanagari) text into readable, faithful English. "
            'Respond STRICTLY as JSON: {"english": "..."} with no markdown.\n\n'
            f"SANSKRIT:\n{text}"
        )
        raw = await chat.send_message(UserMessage(text=prompt))
        parsed = _parse_llm_json(raw)
        return {"english": (parsed.get("english") or "").strip()}
    except Exception as e:
        logger.exception("Translate failed")
        raise HTTPException(status_code=500, detail=f"Translate failed: {e}")


# ------------------------------------------------------------------
# Manuscripts DB
# ------------------------------------------------------------------


def _to_summary(doc: dict) -> ManuscriptSummary:
    pages = doc.get("pages", []) or []
    thumbnail = pages[0]["image_data_url"] if pages and pages[0].get("image_data_url") else ""
    return ManuscriptSummary(
        id=doc["id"],
        filename=doc.get("filename", "manuscript"),
        created_at=doc.get("created_at", ""),
        translated=bool(doc.get("translated")),
        confidence=int(doc.get("confidence") or 0),
        readable=bool(doc.get("readable", (doc.get("confidence") or 0) >= READABLE_THRESHOLD)),
        pages_count=len(pages),
        word_count=int(doc.get("word_count") or 0),
        thumbnail=thumbnail,
    )


@api_router.get("/manuscripts", response_model=List[ManuscriptSummary])
async def list_manuscripts(
    readable: str = Query("all", pattern="^(all|readable|non_readable)$"),
    q: Optional[str] = None,
):
    filt: dict = {}
    if readable == "readable":
        filt["readable"] = True
    elif readable == "non_readable":
        filt["readable"] = False
    if q:
        rx = re.compile(re.escape(q), re.IGNORECASE)
        filt["$or"] = [
            {"filename": rx},
            {"sanskrit": rx},
            {"english": rx},
            {"iast": rx},
        ]
    cursor = db.extractions.find(filt, {"_id": 0}).sort("created_at", -1).limit(200)
    items = []
    async for doc in cursor:
        items.append(_to_summary(doc))
    return items


@api_router.get("/manuscripts/{extraction_id}", response_model=ExtractResponse)
async def get_manuscript(extraction_id: str):
    doc = await db.extractions.find_one({"id": extraction_id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Manuscript not found.")
    doc.setdefault("iast", "")
    doc.setdefault("notes", "")
    doc.setdefault("confidence", 0)
    doc.setdefault("summary", "")
    doc.setdefault("readable", int(doc.get("confidence") or 0) >= READABLE_THRESHOLD)
    doc.setdefault("word_count", 0)
    return ExtractResponse(**doc)


# Alias kept for the previous permalink URL
@api_router.get("/extraction/{extraction_id}", response_model=ExtractResponse)
async def get_extraction_alias(extraction_id: str):
    return await get_manuscript(extraction_id)


@api_router.delete("/manuscripts/{extraction_id}")
async def delete_manuscript(extraction_id: str):
    res = await db.extractions.delete_one({"id": extraction_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Manuscript not found.")
    # Remove from dictionary sources
    await db.dictionary.update_many(
        {"manuscripts": extraction_id},
        {"$pull": {"manuscripts": extraction_id}},
    )
    await db.dictionary.delete_many({"manuscripts": {"$size": 0}})
    return {"ok": True}


@api_router.post("/manuscripts/{extraction_id}/summarize")
async def summarize_manuscript(extraction_id: str):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(status_code=500, detail="LLM key not configured on server.")
    doc = await db.extractions.find_one({"id": extraction_id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Manuscript not found.")
    sanskrit = doc.get("sanskrit", "").strip()
    english = doc.get("english", "").strip()
    if not sanskrit and not english:
        raise HTTPException(status_code=400, detail="No text to summarize.")
    try:
        chat = _new_chat(
            "You are a Sanskrit scholar and literary critic. Summarize manuscripts "
            "clearly, respectfully, and in accessible English."
        )
        body = english if english else sanskrit
        prompt = (
            "Summarize the following manuscript in 3-5 sentences. Highlight themes, key ideas, "
            "and any references to gods, rituals, ethics, or scientific concepts. "
            'Respond STRICTLY as JSON: {"summary": "..."}. No markdown.\n\n'
            f"TEXT:\n{body}"
        )
        raw = await chat.send_message(UserMessage(text=prompt))
        parsed = _parse_llm_json(raw)
        summary = (parsed.get("summary") or "").strip()
        if not summary:
            summary = str(raw).strip()
        await db.extractions.update_one({"id": extraction_id}, {"$set": {"summary": summary}})
        return {"summary": summary}
    except Exception as e:
        logger.exception("Summarize failed")
        raise HTTPException(status_code=500, detail=f"Summarize failed: {e}")


# ------------------------------------------------------------------
# Dictionary
# ------------------------------------------------------------------


@api_router.get("/dictionary", response_model=List[DictionaryEntry])
async def list_dictionary(
    q: Optional[str] = None,
    sort: str = Query("count", pattern="^(count|recent|alpha)$"),
    limit: int = 300,
):
    filt: dict = {}
    if q:
        rx = re.compile(re.escape(q), re.IGNORECASE)
        filt["$or"] = [
            {"sanskrit": rx},
            {"iast": rx},
            {"iast_lower": rx},
            {"meaning": rx},
        ]
    if sort == "count":
        sort_spec = [("count", -1), ("iast_lower", 1)]
    elif sort == "recent":
        sort_spec = [("created_at", -1)]
    else:
        sort_spec = [("iast_lower", 1)]
    cursor = db.dictionary.find(filt, {"_id": 0}).sort(sort_spec).limit(int(limit))
    items = []
    async for doc in cursor:
        items.append(
            DictionaryEntry(
                id=doc["id"],
                sanskrit=doc.get("sanskrit", ""),
                iast=doc.get("iast", ""),
                count=int(doc.get("count") or 0),
                meaning=doc.get("meaning", ""),
                manuscripts=doc.get("manuscripts", []),
                created_at=doc.get("created_at", ""),
            )
        )
    return items


@api_router.post("/dictionary/lookup", response_model=DictionaryEntry)
async def lookup_dictionary(payload: DictionaryLookupRequest):
    """Enrich a dictionary entry with English meaning via Gemini (Sanskrit-scholar prompt)."""
    if not EMERGENT_LLM_KEY:
        raise HTTPException(status_code=500, detail="LLM key not configured on server.")
    filt: dict = {}
    if payload.id:
        filt["id"] = payload.id
    elif payload.sanskrit:
        filt["sanskrit"] = payload.sanskrit
    elif payload.iast:
        filt["iast_lower"] = payload.iast.lower()
    else:
        raise HTTPException(status_code=400, detail="Provide id, sanskrit or iast.")

    doc = await db.dictionary.find_one(filt)
    if not doc:
        raise HTTPException(status_code=404, detail="Word not found in dictionary.")

    if doc.get("meaning"):
        # already looked up
        return DictionaryEntry(
            id=doc["id"],
            sanskrit=doc.get("sanskrit", ""),
            iast=doc.get("iast", ""),
            count=int(doc.get("count") or 0),
            meaning=doc.get("meaning", ""),
            manuscripts=doc.get("manuscripts", []),
            created_at=doc.get("created_at", ""),
        )

    try:
        chat = _new_chat(
            "You are a lexicographer of classical Sanskrit, drawing on Monier-Williams and "
            "the Cologne Digital Sanskrit Dictionaries. Give concise, accurate English glosses."
        )
        word = doc.get("sanskrit") or doc.get("iast") or ""
        prompt = (
            f"Provide a concise English gloss for the Sanskrit word: '{word}'. "
            'Respond STRICTLY as JSON: {"meaning": "..."} with a 5-15 word English gloss. '
            "If uncertain, give the most likely meaning and mark with '(uncertain)'."
        )
        raw = await chat.send_message(UserMessage(text=prompt))
        parsed = _parse_llm_json(raw)
        meaning = (parsed.get("meaning") or "").strip() or "(no gloss found)"
        await db.dictionary.update_one({"_id": doc["_id"]}, {"$set": {"meaning": meaning}})
        doc["meaning"] = meaning
        return DictionaryEntry(
            id=doc["id"],
            sanskrit=doc.get("sanskrit", ""),
            iast=doc.get("iast", ""),
            count=int(doc.get("count") or 0),
            meaning=meaning,
            manuscripts=doc.get("manuscripts", []),
            created_at=doc.get("created_at", ""),
        )
    except Exception as e:
        logger.exception("Dictionary lookup failed")
        raise HTTPException(status_code=500, detail=f"Lookup failed: {e}")


# ------------------------------------------------------------------
# Stats
# ------------------------------------------------------------------


@api_router.get("/stats")
async def dataset_stats():
    total = await db.extractions.count_documents({})
    readable = await db.extractions.count_documents({"readable": True})
    non_readable = total - readable

    # Confidence buckets
    buckets = {"0-40": 0, "40-60": 0, "60-80": 0, "80-100": 0}
    total_conf = 0
    total_words = 0
    async for doc in db.extractions.find({}, {"_id": 0, "confidence": 1, "word_count": 1}):
        c = int(doc.get("confidence") or 0)
        total_conf += c
        total_words += int(doc.get("word_count") or 0)
        if c < 40:
            buckets["0-40"] += 1
        elif c < 60:
            buckets["40-60"] += 1
        elif c < 80:
            buckets["60-80"] += 1
        else:
            buckets["80-100"] += 1
    avg_conf = int(total_conf / total) if total else 0

    dict_count = await db.dictionary.count_documents({})
    top_cursor = db.dictionary.find({}, {"_id": 0}).sort("count", -1).limit(10)
    top_words = []
    async for d in top_cursor:
        top_words.append(
            {
                "sanskrit": d.get("sanskrit", ""),
                "iast": d.get("iast", ""),
                "count": int(d.get("count") or 0),
            }
        )

    return {
        "total_manuscripts": total,
        "readable": readable,
        "non_readable": non_readable,
        "avg_confidence": avg_conf,
        "confidence_buckets": buckets,
        "dictionary_size": dict_count,
        "total_words_extracted": total_words,
        "top_words": top_words,
    }


# ------------------------------------------------------------------
# App wiring
# ------------------------------------------------------------------

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
