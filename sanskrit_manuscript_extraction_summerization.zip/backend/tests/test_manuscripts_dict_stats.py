"""Backend tests for new endpoints: manuscripts CRUD, summarize, dictionary, stats, PDF extract."""
import io
import os
import pytest
import requests
from pathlib import Path
from dotenv import load_dotenv

import fitz  # PyMuPDF

load_dotenv(Path("/app/frontend/.env"))
BASE_URL = os.environ["REACT_APP_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"

FIXTURE_JPG = "/app/test_fixtures/sanskrit_test.jpg"
LLM_TIMEOUT = 240


@pytest.fixture(scope="session")
def s():
    return requests.Session()


@pytest.fixture(scope="session")
def image_bytes():
    return Path(FIXTURE_JPG).read_bytes()


@pytest.fixture(scope="session")
def pdf_bytes(image_bytes):
    """Build a 2-page PDF from the test image using PyMuPDF."""
    src = fitz.open(stream=image_bytes, filetype="jpeg")
    pdf = fitz.open()
    rect = fitz.Rect(0, 0, 595, 842)  # A4
    for _ in range(2):
        page = pdf.new_page(width=rect.width, height=rect.height)
        page.insert_image(rect, stream=image_bytes)
    out = pdf.tobytes()
    pdf.close()
    src.close()
    return out


@pytest.fixture(scope="session")
def created_manuscript(s, image_bytes):
    """POST /api/extract with translate=true and return the response body."""
    files = {"file": ("sanskrit_test.jpg", image_bytes, "image/jpeg")}
    r = s.post(f"{API}/extract", files=files, data={"translate": "true"}, timeout=LLM_TIMEOUT)
    assert r.status_code == 200, r.text[:400]
    body = r.json()
    assert body["id"]
    return body


# ---------- Extract: new fields + persistence ----------
class TestExtractNewFields:
    def test_extract_has_pages_and_readable(self, created_manuscript):
        body = created_manuscript
        assert isinstance(body.get("pages"), list) and len(body["pages"]) >= 1
        p = body["pages"][0]
        for k in ("page_number", "sanskrit", "iast", "english", "confidence", "image_data_url"):
            assert k in p, f"page missing {k}"
        assert p["image_data_url"].startswith("data:image/"), p["image_data_url"][:60]
        assert isinstance(body.get("readable"), bool)
        assert body.get("word_count", 0) > 0
        assert isinstance(body.get("iast"), str) and len(body["iast"]) >= 0

    def test_extract_persisted_to_db(self, s, created_manuscript):
        mid = created_manuscript["id"]
        r = s.get(f"{API}/manuscripts/{mid}", timeout=30)
        assert r.status_code == 200
        got = r.json()
        assert got["id"] == mid
        assert got["pages"][0]["image_data_url"].startswith("data:image/")


# ---------- Manuscripts DB ----------
class TestManuscriptsList:
    def test_list_all(self, s, created_manuscript):
        r = s.get(f"{API}/manuscripts?readable=all", timeout=30)
        assert r.status_code == 200
        arr = r.json()
        assert isinstance(arr, list) and len(arr) >= 1
        item = next((x for x in arr if x["id"] == created_manuscript["id"]), None)
        assert item is not None
        assert "thumbnail" in item
        assert "readable" in item

    def test_list_readable_filter(self, s):
        for f in ("readable", "non_readable"):
            r = s.get(f"{API}/manuscripts?readable={f}", timeout=30)
            assert r.status_code == 200
            for it in r.json():
                assert it["readable"] is (f == "readable")


# ---------- Summarize ----------
class TestSummarize:
    def test_summarize_returns_text(self, s, created_manuscript):
        mid = created_manuscript["id"]
        r = s.post(f"{API}/manuscripts/{mid}/summarize", timeout=LLM_TIMEOUT)
        assert r.status_code == 200, r.text[:400]
        data = r.json()
        assert "summary" in data
        assert isinstance(data["summary"], str) and len(data["summary"].strip()) > 10

    def test_summarize_persisted(self, s, created_manuscript):
        mid = created_manuscript["id"]
        r = s.get(f"{API}/manuscripts/{mid}", timeout=30)
        assert r.status_code == 200
        assert r.json().get("summary", "").strip() != ""


# ---------- Dictionary ----------
class TestDictionary:
    def test_list_dictionary(self, s, created_manuscript):
        r = s.get(f"{API}/dictionary?sort=count", timeout=30)
        assert r.status_code == 200
        arr = r.json()
        assert isinstance(arr, list) and len(arr) >= 1
        for k in ("id", "sanskrit", "iast", "count"):
            assert k in arr[0]

    def test_dictionary_sort_alpha(self, s):
        r = s.get(f"{API}/dictionary?sort=alpha&limit=50", timeout=30)
        assert r.status_code == 200

    def test_dictionary_search(self, s):
        r = s.get(f"{API}/dictionary?q=a&limit=20", timeout=30)
        assert r.status_code == 200

    def test_dictionary_lookup(self, s):
        # take first entry
        arr = s.get(f"{API}/dictionary?sort=count&limit=1", timeout=30).json()
        if not arr:
            pytest.skip("dictionary empty")
        eid = arr[0]["id"]
        r = s.post(f"{API}/dictionary/lookup", json={"id": eid}, timeout=LLM_TIMEOUT)
        assert r.status_code == 200, r.text[:400]
        got = r.json()
        assert got["id"] == eid
        assert isinstance(got.get("meaning"), str) and len(got["meaning"].strip()) > 0


# ---------- Stats ----------
class TestStats:
    def test_stats_shape(self, s, created_manuscript):
        r = s.get(f"{API}/stats", timeout=30)
        assert r.status_code == 200
        data = r.json()
        for k in (
            "total_manuscripts",
            "readable",
            "non_readable",
            "avg_confidence",
            "confidence_buckets",
            "dictionary_size",
            "total_words_extracted",
            "top_words",
        ):
            assert k in data, f"stats missing {k}"
        for b in ("0-40", "40-60", "60-80", "80-100"):
            assert b in data["confidence_buckets"]
        assert data["total_manuscripts"] >= 1


# ---------- PDF extract ----------
class TestPdfExtract:
    def test_extract_pdf_multipage(self, s, pdf_bytes):
        files = {"file": ("test.pdf", pdf_bytes, "application/pdf")}
        r = s.post(f"{API}/extract", files=files, data={"translate": "false"}, timeout=LLM_TIMEOUT * 2)
        assert r.status_code == 200, r.text[:400]
        body = r.json()
        assert len(body["pages"]) >= 2
        pnums = [p["page_number"] for p in body["pages"]]
        assert pnums == sorted(pnums)
        for p in body["pages"]:
            assert p["image_data_url"].startswith("data:image/")


# ---------- Delete (run last) ----------
class TestDelete:
    def test_delete_and_verify_removed(self, s, created_manuscript):
        mid = created_manuscript["id"]
        r = s.delete(f"{API}/manuscripts/{mid}", timeout=30)
        assert r.status_code == 200
        assert r.json().get("ok") is True
        g = s.get(f"{API}/manuscripts/{mid}", timeout=30)
        assert g.status_code == 404
