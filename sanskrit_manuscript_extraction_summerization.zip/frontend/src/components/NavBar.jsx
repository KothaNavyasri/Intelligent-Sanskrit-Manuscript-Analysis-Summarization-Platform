import { Link, NavLink } from "react-router-dom";
import { Feather } from "lucide-react";

const links = [
  { to: "/", label: "Home", testid: "nav-home" },
  { to: "/manuscripts", label: "Manuscripts", testid: "nav-manuscripts" },
  { to: "/dictionary", label: "Dictionary", testid: "nav-dictionary" },
  { to: "/stats", label: "Statistics", testid: "nav-stats" },
];

export default function NavBar() {
  return (
    <header className="relative z-20 border-b border-border/70 backdrop-blur-sm bg-background/80 sticky top-0">
      <div className="max-w-7xl mx-auto px-6 md:px-10 h-16 flex items-center justify-between gap-6">
        <Link to="/" className="flex items-center gap-3 min-w-0" data-testid="brand">
          <Feather strokeWidth={1.25} className="w-5 h-5 text-primary" />
          <div className="font-display text-2xl tracking-tight leading-none">Vidyā</div>
          <span className="font-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground ml-2 hidden lg:inline">
            Sanskrit · OCR · Translation
          </span>
        </Link>
        <nav className="flex items-center gap-1 md:gap-2 overflow-x-auto">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              data-testid={l.testid}
              className={({ isActive }) =>
                `font-ui text-[11px] uppercase tracking-[0.22em] px-3 py-2 border-b transition-colors ${
                  isActive
                    ? "border-primary text-primary"
                    : "border-transparent text-foreground/70 hover:text-primary"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
}
